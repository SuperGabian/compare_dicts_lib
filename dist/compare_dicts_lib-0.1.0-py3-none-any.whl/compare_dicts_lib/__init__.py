__version__ = "0.1.0"

from .compare_dicts import compare_dicts

__all__ = ["compare_dicts"]